# ZESUS — Maison de Couture

> A full-stack luxury fashion e-commerce platform built with Spring Boot, MongoDB, and vanilla HTML/CSS/JS.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JS |
| Backend | Java 17, Spring Boot 3.2 |
| Database | MongoDB 6+ |
| Auth | JWT (Access + Refresh tokens) |
| Payments | Stripe Checkout |
| Build | Maven 3.9 |

---

## Project Structure

```
zesus/
├── frontend/
│   └── index.html              ← Complete storefront (single file)
│
├── backend/
│   ├── pom.xml                 ← Maven dependencies (Stripe included)
│   └── src/main/
│       ├── java/com/zesus/
│       │   ├── ZesusApplication.java
│       │   ├── config/
│       │   │   ├── SecurityConfig.java   ← JWT + CORS config
│       │   │   └── DataSeeder.java       ← Seeds admin + 5 products
│       │   ├── controller/
│       │   │   ├── Controllers.java      ← Auth, Product, Cart, Order, Admin
│       │   │   └── StripeController.java ← Stripe checkout session
│       │   ├── model/
│       │   │   ├── User.java
│       │   │   ├── Product.java          ← Includes variants (size/color/stock)
│       │   │   ├── Order.java
│       │   │   ├── Cart.java
│       │   │   └── Address.java
│       │   ├── repository/               ← MongoDB repositories
│       │   ├── security/
│       │   │   ├── JwtUtil.java
│       │   │   └── JwtAuthFilter.java
│       │   └── service/                  ← Business logic
│       └── resources/
│           └── application.yml          ← All config (uses env vars)
│
├── .gitignore
└── README.md
```

---

## Quick Start

### 1. Prerequisites

Make sure these are installed:

```bash
java -version      # Java 17+
mvn -version       # Maven 3.9+
mongod --version   # MongoDB 6+
python3 --version  # Python 3 (for frontend server)
```

### 2. Start MongoDB

```bash
# macOS
brew services start mongodb-community

# Windows (PowerShell as Admin)
net start MongoDB

# Linux
sudo systemctl start mongod
```

### 3. Set Environment Variables

```bash
# macOS / Linux
export MONGODB_URI=mongodb://localhost:27017/zesus
export JWT_SECRET=ZesusOlympianSecretKeyThatIsAtLeast256BitsLong!
export ADMIN_EMAIL=admin@zesus.com
export ADMIN_PASSWORD=Admin@Zesus2026!

# Stripe (get keys from https://stripe.com/dashboard)
export STRIPE_SECRET_KEY=sk_test_your_key_here
export STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here

# Windows PowerShell
$env:MONGODB_URI="mongodb://localhost:27017/zesus"
$env:JWT_SECRET="ZesusOlympianSecretKeyThatIsAtLeast256BitsLong!"
$env:ADMIN_EMAIL="admin@zesus.com"
$env:ADMIN_PASSWORD="Admin@Zesus2026!"
```

### 4. Start the Backend

```bash
cd backend
mvn spring-boot:run
```

Wait for: `Started ZesusApplication in X seconds`

Verify: open [http://localhost:8080/api/v1/products](http://localhost:8080/api/v1/products)
You should see JSON with 5 seeded ZESUS products.

### 5. Serve the Frontend

```bash
cd frontend
python3 -m http.server 3000
```

Open: [http://localhost:3000](http://localhost:3000)

The green **"API Connected"** badge in the bottom-left confirms everything is wired up.

---

## What Auto-Seeds on First Run

When Spring Boot starts for the first time against an empty database, `DataSeeder.java` automatically creates:

- **Admin account** — using your `ADMIN_EMAIL` + `ADMIN_PASSWORD` env vars
- **5 luxury products** — Athena Overcoat, Hermes Blazer, Artemis Gown, Apollo Shirt, Poseidon Coat (all with variants)

---

## API Reference

### Authentication

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/v1/auth/register` | Public | Create account → returns JWT |
| POST | `/api/v1/auth/login` | Public | Login → returns JWT |
| POST | `/api/v1/auth/refresh` | Public | Refresh access token |
| POST | `/api/v1/auth/logout` | Bearer | Invalidate session |

### Products

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/v1/products` | Public | All products (paginated) |
| GET | `/api/v1/products/{id}` | Public | Single product by ID |
| GET | `/api/v1/products/featured` | Public | Featured products |
| GET | `/api/v1/products/new-arrivals` | Public | Latest 8 products |
| GET | `/api/v1/products/search?q=cashmere` | Public | Full-text search |
| GET | `/api/v1/products/category/{category}` | Public | Filter by category |
| GET | `/api/v1/products/collection/{name}` | Public | Filter by collection |

### Cart

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/v1/cart` | Bearer | Get current cart |
| POST | `/api/v1/cart/items` | Bearer | Add item |
| PATCH | `/api/v1/cart/items` | Bearer | Update qty (0 = remove) |
| DELETE | `/api/v1/cart` | Bearer | Clear cart |

### Orders

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/v1/orders` | Bearer | Create order from cart |
| GET | `/api/v1/orders` | Bearer | My order history |
| GET | `/api/v1/orders/{id}` | Bearer | Order detail |

### Payments (Stripe)

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/v1/payments/create-checkout-session` | Bearer | Creates Stripe session → returns `{ url }` |

### Admin

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/v1/admin/products` | Admin | Create product |
| PATCH | `/api/v1/admin/products/{id}` | Admin | Update product |
| DELETE | `/api/v1/admin/products/{id}` | Admin | Soft-delete product |
| GET | `/api/v1/admin/orders` | Admin | All orders |
| PATCH | `/api/v1/admin/orders/{id}/status` | Admin | Update order status |

---

## Stripe Integration

1. Create a free account at [stripe.com](https://stripe.com)
2. Go to **Developers → API Keys** and copy your test keys
3. Set `STRIPE_SECRET_KEY` and `STRIPE_PUBLISHABLE_KEY` env vars
4. Test card: `4242 4242 4242 4242` · any future expiry · any CVC

---

## MongoDB Shell (Debugging)

```bash
mongosh

use zesus

# View all collections
show collections

# View all products
db.products.find().pretty()

# View all users
db.users.find({}, { email: 1, roles: 1 }).pretty()

# View all orders
db.orders.find().sort({ createdAt: -1 }).pretty()

# Clear all carts (reset)
db.carts.deleteMany({})

exit
```

---

## Deployment

### Frontend → Netlify
Drag and drop `frontend/index.html` to [netlify.com/drop](https://app.netlify.com/drop)

### Backend → Railway
```bash
npm install -g @railway/cli
cd backend
railway login
railway init
railway up
```
Set environment variables in the Railway dashboard.

### Database → MongoDB Atlas
1. Create a free cluster at [mongodb.com/atlas](https://www.mongodb.com/atlas)
2. Get your connection string
3. Set `MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/zesus`

---

## Default Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@zesus.com | Admin@Zesus2026! |

> Change these in production via environment variables.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Red "API Offline" badge | Start Spring Boot: `cd backend && mvn spring-boot:run` |
| Products don't load | Start MongoDB: `brew services start mongodb-community` |
| CORS error in browser console | Add your frontend port to `cors.allowed-origins` in `application.yml` |
| Login returns 401 | Check `db.users.find()` in mongosh to verify user exists |
| Port 8080 already in use | Add `server.port=9090` to `application.yml` |
| `mvn: command not found` | Install Maven from [maven.apache.org](https://maven.apache.org/install.html) |

---

## License

© 2026 ZESUS Maison de Couture. All rights reserved.

> *"Where divinity meets the wardrobe."*
