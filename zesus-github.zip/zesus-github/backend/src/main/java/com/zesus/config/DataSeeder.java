package com.zesus.config;

import com.zesus.model.Product;
import com.zesus.model.User;
import com.zesus.repository.ProductRepository;
import com.zesus.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${zesus.admin.email}")
    private String adminEmail;

    @Value("${zesus.admin.password}")
    private String adminPassword;

    @Override
    public void run(String... args) {
        seedAdmin();
        seedProducts();
    }

    private void seedAdmin() {
        if (!userRepository.existsByEmail(adminEmail)) {
            User admin = User.builder()
                    .email(adminEmail)
                    .password(passwordEncoder.encode(adminPassword))
                    .firstName("ZESUS")
                    .lastName("Admin")
                    .roles(Set.of(User.Role.ROLE_ADMIN, User.Role.ROLE_CUSTOMER))
                    .enabled(true)
                    .emailVerified(true)
                    .build();
            userRepository.save(admin);
            log.info("✦ Admin account created: {}", adminEmail);
        }
    }

    private void seedProducts() {
        if (productRepository.count() == 0) {
            List<Product> products = List.of(
                Product.builder()
                    .name("Athena Overcoat")
                    .slug("athena-overcoat")
                    .description("A masterwork in double-faced cashmere, the Athena Overcoat draws its silhouette from the classical statuary of ancient Greece. Structured shoulders, a fluid hem, and hand-finished edges define this enduring piece.")
                    .shortDescription("Double-faced cashmere & silk overcoat. Handcrafted in Florence.")
                    .price(new BigDecimal("4850"))
                    .currency("EUR")
                    .category("womens")
                    .subcategory("coats")
                    .collection("SS2026 — Olympus")
                    .material("Cashmere & Silk")
                    .origin("Handcrafted in Florence")
                    .featured(true)
                    .active(true)
                    .tags(List.of("outerwear", "cashmere", "ss2026", "featured"))
                    .variants(List.of(
                        Product.ProductVariant.builder().sku("AO-BLK-XS").size("XS").color("Onyx Black").stock(3).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("AO-BLK-S").size("S").color("Onyx Black").stock(5).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("AO-BLK-M").size("M").color("Onyx Black").stock(4).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("AO-IVR-S").size("S").color("Ivory").stock(2).priceAdjustment(BigDecimal.ZERO).build()
                    ))
                    .build(),

                Product.builder()
                    .name("Hermes Blazer")
                    .slug("hermes-blazer")
                    .description("Tailored from the finest Super 180s virgin wool, the Hermes Blazer is a study in understated authority. Each jacket is cut and hand-sewn over 200 hours in our Milanese atelier.")
                    .shortDescription("Super 180s virgin wool blazer. Tailored in Milan.")
                    .price(new BigDecimal("3200"))
                    .currency("EUR")
                    .category("mens")
                    .subcategory("blazers")
                    .collection("SS2026 — Olympus")
                    .material("Virgin Wool Super 180s")
                    .origin("Tailored in Milan")
                    .featured(true)
                    .active(true)
                    .tags(List.of("tailoring", "wool", "ss2026"))
                    .variants(List.of(
                        Product.ProductVariant.builder().sku("HB-NVY-48").size("48").color("Midnight Navy").stock(4).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("HB-NVY-50").size("50").color("Midnight Navy").stock(6).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("HB-CHR-50").size("50").color("Charcoal").stock(3).priceAdjustment(BigDecimal.ZERO).build()
                    ))
                    .build(),

                Product.builder()
                    .name("Artemis Gown")
                    .slug("artemis-gown")
                    .description("Flowing duchess satin draped in the tradition of Grecian himation, the Artemis Gown commands attention with its asymmetric neckline and hand-pleated bodice. A garment born for extraordinary evenings.")
                    .shortDescription("Hand-pleated duchess satin evening gown.")
                    .price(new BigDecimal("7600"))
                    .currency("EUR")
                    .category("womens")
                    .subcategory("gowns")
                    .collection("SS2026 — Olympus")
                    .material("Duchess Satin")
                    .origin("Atelier Paris")
                    .featured(true)
                    .active(true)
                    .tags(List.of("eveningwear", "satin", "couture", "ss2026"))
                    .variants(List.of(
                        Product.ProductVariant.builder().sku("AG-GLD-34").size("34").color("Olympic Gold").stock(2).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("AG-GLD-36").size("36").color("Olympic Gold").stock(3).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("AG-ONX-36").size("36").color("Onyx").stock(2).priceAdjustment(BigDecimal.ZERO).build()
                    ))
                    .build(),

                Product.builder()
                    .name("Apollo Shirt")
                    .slug("apollo-shirt")
                    .description("Woven from two-ply Egyptian cotton with a 200-thread count, the Apollo Shirt brings solar radiance to daily dressing. Mother-of-pearl buttons and a half-placket lend it quiet distinction.")
                    .shortDescription("Two-ply Egyptian cotton dress shirt.")
                    .price(new BigDecimal("890"))
                    .currency("EUR")
                    .category("mens")
                    .subcategory("shirts")
                    .collection("SS2026 — Olympus")
                    .material("Egyptian Cotton 200TC")
                    .origin("Handcrafted in Naples")
                    .active(true)
                    .tags(List.of("shirts", "cotton", "ss2026"))
                    .variants(List.of(
                        Product.ProductVariant.builder().sku("AS-WHT-38").size("38").color("White").stock(10).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("AS-WHT-40").size("40").color("White").stock(8).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("AS-ECR-40").size("40").color("Ecru").stock(6).priceAdjustment(BigDecimal.ZERO).build()
                    ))
                    .build(),

                Product.builder()
                    .name("Poseidon Coat")
                    .slug("poseidon-coat")
                    .description("Commanding as the god of the seas, the Poseidon Coat is sculpted from heavyweight double-face wool in deep oceanic tones. Its sweeping silhouette and raglan construction make it an instant landmark.")
                    .shortDescription("Heavyweight double-face wool coat.")
                    .price(new BigDecimal("6200"))
                    .currency("EUR")
                    .category("mens")
                    .subcategory("coats")
                    .collection("SS2026 — Olympus")
                    .material("Double-face Wool")
                    .origin("Handcrafted in Florence")
                    .featured(true)
                    .active(true)
                    .tags(List.of("outerwear", "wool", "ss2026", "featured"))
                    .variants(List.of(
                        Product.ProductVariant.builder().sku("PC-OCN-50").size("50").color("Ocean Blue").stock(3).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("PC-BLK-50").size("50").color("Black").stock(4).priceAdjustment(BigDecimal.ZERO).build(),
                        Product.ProductVariant.builder().sku("PC-BLK-52").size("52").color("Black").stock(2).priceAdjustment(BigDecimal.ZERO).build()
                    ))
                    .build()
            );

            productRepository.saveAll(products);
            log.info("✦ {} sample products seeded", products.size());
        }
    }
}
