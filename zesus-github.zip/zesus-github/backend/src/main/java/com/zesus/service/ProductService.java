package com.zesus.service;

import com.zesus.dto.ProductDto;
import com.zesus.exception.ApiException;
import com.zesus.model.Product;
import com.zesus.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.util.List;
import java.util.regex.Pattern;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    // ── Public ────────────────────────────────────

    public Page<ProductDto.ProductResponse> getAllProducts(int page, int size, String sortBy, String direction) {
        Sort sort = direction.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return productRepository.findByActiveTrue(pageable).map(this::toResponse);
    }

    public ProductDto.ProductResponse getBySlug(String slug) {
        return productRepository.findBySlug(slug)
                .map(this::toResponse)
                .orElseThrow(() -> new ApiException("Product not found", HttpStatus.NOT_FOUND));
    }

    public ProductDto.ProductResponse getById(String id) {
        return productRepository.findById(id)
                .map(this::toResponse)
                .orElseThrow(() -> new ApiException("Product not found", HttpStatus.NOT_FOUND));
    }

    public Page<ProductDto.ProductResponse> getByCategory(String category, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return productRepository.findByCategoryAndActiveTrue(category, pageable).map(this::toResponse);
    }

    public Page<ProductDto.ProductResponse> getByCollection(String collection, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return productRepository.findByCollectionAndActiveTrue(collection, pageable).map(this::toResponse);
    }

    public List<ProductDto.ProductResponse> getFeatured() {
        return productRepository.findByFeaturedTrueAndActiveTrue().stream().map(this::toResponse).toList();
    }

    public List<ProductDto.ProductResponse> getNewArrivals() {
        return productRepository.findTop8ByActiveTrueOrderByCreatedAtDesc().stream().map(this::toResponse).toList();
    }

    public Page<ProductDto.ProductResponse> search(String query, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return productRepository.searchByText(query, pageable).map(this::toResponse);
    }

    public Page<ProductDto.ProductResponse> filter(String category, BigDecimal minPrice,
                                                    BigDecimal maxPrice, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("price").ascending());
        if (category != null && !category.isBlank()) {
            return productRepository.findByCategoryAndPriceRange(category, minPrice, maxPrice, pageable).map(this::toResponse);
        }
        return productRepository.findByPriceRange(minPrice, maxPrice, pageable).map(this::toResponse);
    }

    // ── Admin ─────────────────────────────────────

    public ProductDto.ProductResponse createProduct(ProductDto.CreateProductRequest req) {
        Product product = Product.builder()
                .name(req.getName())
                .slug(generateSlug(req.getName()))
                .description(req.getDescription())
                .shortDescription(req.getShortDescription())
                .price(req.getPrice())
                .compareAtPrice(req.getCompareAtPrice())
                .currency("EUR")
                .category(req.getCategory())
                .subcategory(req.getSubcategory())
                .collection(req.getCollection())
                .material(req.getMaterial())
                .origin(req.getOrigin())
                .images(req.getImages())
                .variants(req.getVariants())
                .tags(req.getTags())
                .featured(req.isFeatured())
                .build();

        return toResponse(productRepository.save(product));
    }

    public ProductDto.ProductResponse updateProduct(String id, ProductDto.UpdateProductRequest req) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ApiException("Product not found", HttpStatus.NOT_FOUND));

        if (req.getName() != null) { product.setName(req.getName()); product.setSlug(generateSlug(req.getName())); }
        if (req.getDescription() != null) product.setDescription(req.getDescription());
        if (req.getShortDescription() != null) product.setShortDescription(req.getShortDescription());
        if (req.getPrice() != null) product.setPrice(req.getPrice());
        if (req.getCompareAtPrice() != null) product.setCompareAtPrice(req.getCompareAtPrice());
        if (req.getCategory() != null) product.setCategory(req.getCategory());
        if (req.getSubcategory() != null) product.setSubcategory(req.getSubcategory());
        if (req.getCollection() != null) product.setCollection(req.getCollection());
        if (req.getMaterial() != null) product.setMaterial(req.getMaterial());
        if (req.getOrigin() != null) product.setOrigin(req.getOrigin());
        if (req.getImages() != null) product.setImages(req.getImages());
        if (req.getVariants() != null) product.setVariants(req.getVariants());
        if (req.getTags() != null) product.setTags(req.getTags());
        if (req.getActive() != null) product.setActive(req.getActive());
        if (req.getFeatured() != null) product.setFeatured(req.getFeatured());

        return toResponse(productRepository.save(product));
    }

    public void deleteProduct(String id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ApiException("Product not found", HttpStatus.NOT_FOUND));
        product.setActive(false);   // soft delete
        productRepository.save(product);
    }

    // ── Helpers ───────────────────────────────────

    private String generateSlug(String name) {
        String normalized = Normalizer.normalize(name, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(normalized).replaceAll("")
                .toLowerCase()
                .replaceAll("[^a-z0-9\\s-]", "")
                .trim()
                .replaceAll("\\s+", "-");
    }

    public ProductDto.ProductResponse toResponse(Product p) {
        ProductDto.ProductResponse r = new ProductDto.ProductResponse();
        r.setId(p.getId());
        r.setName(p.getName());
        r.setSlug(p.getSlug());
        r.setDescription(p.getDescription());
        r.setShortDescription(p.getShortDescription());
        r.setPrice(p.getPrice());
        r.setCompareAtPrice(p.getCompareAtPrice());
        r.setCurrency(p.getCurrency() != null ? p.getCurrency() : "EUR");
        r.setCategory(p.getCategory());
        r.setSubcategory(p.getSubcategory());
        r.setCollection(p.getCollection());
        r.setMaterial(p.getMaterial());
        r.setOrigin(p.getOrigin());
        r.setImages(p.getImages());
        r.setVariants(p.getVariants());
        r.setTags(p.getTags());
        r.setFeatured(p.isFeatured());
        r.setAverageRating(p.getAverageRating());
        r.setReviewCount(p.getReviewCount());
        r.setCreatedAt(p.getCreatedAt());
        return r;
    }
}
