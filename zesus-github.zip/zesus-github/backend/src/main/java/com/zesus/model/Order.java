package com.zesus.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "orders")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Order {

    @Id
    private String id;

    @Indexed(unique = true)
    private String orderNumber;   // e.g. ZSS-20260001

    @Indexed
    private String userId;

    private String guestEmail;    // for guest checkout

    @Builder.Default
    private List<OrderItem> items = new ArrayList<>();

    private Address shippingAddress;
    private Address billingAddress;

    private BigDecimal subtotal;
    private BigDecimal shippingCost;
    private BigDecimal tax;
    private BigDecimal discount;
    private BigDecimal total;
    private String currency;

    @Builder.Default
    private OrderStatus status = OrderStatus.PENDING;

    private PaymentInfo payment;

    private String couponCode;
    private String notes;

    private Instant estimatedDelivery;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

    // ── Nested types ──────────────────────────────

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrderItem {
        private String productId;
        private String productName;
        private String sku;
        private String size;
        private String color;
        private String imageUrl;
        private Integer quantity;
        private BigDecimal unitPrice;
        private BigDecimal totalPrice;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PaymentInfo {
        private String provider;       // stripe, paypal, etc.
        private String transactionId;
        private PaymentStatus status;
        private String last4;          // last 4 of card
        private String brand;          // visa, mastercard, etc.
        private Instant paidAt;
    }

    public enum OrderStatus {
        PENDING,
        PAYMENT_CONFIRMED,
        PROCESSING,
        SHIPPED,
        OUT_FOR_DELIVERY,
        DELIVERED,
        CANCELLED,
        REFUNDED,
        RETURN_REQUESTED,
        RETURNED
    }

    public enum PaymentStatus {
        PENDING,
        PAID,
        FAILED,
        REFUNDED,
        PARTIALLY_REFUNDED
    }
}
