package com.zesus.controller;

import com.zesus.dto.*;
import com.zesus.model.Cart;
import com.zesus.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

// ════════════════════════════════════════════
//  AUTH CONTROLLER
// ════════════════════════════════════════════
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthDto.TokenResponse> register(@Valid @RequestBody AuthDto.RegisterRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.register(req));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthDto.TokenResponse> login(@Valid @RequestBody AuthDto.LoginRequest req) {
        return ResponseEntity.ok(authService.login(req));
    }

    @PostMapping("/refresh")
    public ResponseEntity<AuthDto.TokenResponse> refresh(@Valid @RequestBody AuthDto.RefreshRequest req) {
        return ResponseEntity.ok(authService.refresh(req));
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(@AuthenticationPrincipal UserDetails user) {
        authService.logout(user.getUsername());
        return ResponseEntity.noContent().build();
    }
}

// ════════════════════════════════════════════
//  PRODUCT CONTROLLER
// ════════════════════════════════════════════
@RestController
@RequestMapping("/api/v1/products")
@RequiredArgsConstructor
class ProductController {

    private final ProductService productService;

    @GetMapping
    public ResponseEntity<Page<ProductDto.ProductResponse>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        return ResponseEntity.ok(productService.getAllProducts(page, size, sortBy, direction));
    }

    @GetMapping("/featured")
    public ResponseEntity<List<ProductDto.ProductResponse>> getFeatured() {
        return ResponseEntity.ok(productService.getFeatured());
    }

    @GetMapping("/new-arrivals")
    public ResponseEntity<List<ProductDto.ProductResponse>> getNewArrivals() {
        return ResponseEntity.ok(productService.getNewArrivals());
    }

    @GetMapping("/search")
    public ResponseEntity<Page<ProductDto.ProductResponse>> search(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(productService.search(q, page, size));
    }

    @GetMapping("/filter")
    public ResponseEntity<Page<ProductDto.ProductResponse>> filter(
            @RequestParam(required = false) String category,
            @RequestParam(defaultValue = "0") BigDecimal minPrice,
            @RequestParam(defaultValue = "99999") BigDecimal maxPrice,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(productService.filter(category, minPrice, maxPrice, page, size));
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<Page<ProductDto.ProductResponse>> getByCategory(
            @PathVariable String category,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(productService.getByCategory(category, page, size));
    }

    @GetMapping("/collection/{collection}")
    public ResponseEntity<Page<ProductDto.ProductResponse>> getByCollection(
            @PathVariable String collection,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        return ResponseEntity.ok(productService.getByCollection(collection, page, size));
    }

    @GetMapping("/{slug}")
    public ResponseEntity<ProductDto.ProductResponse> getBySlug(@PathVariable String slug) {
        return ResponseEntity.ok(productService.getBySlug(slug));
    }
}

// ════════════════════════════════════════════
//  CART CONTROLLER
// ════════════════════════════════════════════
@RestController
@RequestMapping("/api/v1/cart")
@RequiredArgsConstructor
class CartController {

    private final CartService cartService;

    @GetMapping
    public ResponseEntity<Cart> getCart(@AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(cartService.getCart(user.getUsername()));
    }

    @PostMapping("/items")
    public ResponseEntity<Cart> addItem(@AuthenticationPrincipal UserDetails user,
                                        @Valid @RequestBody CartDto.AddItemRequest req) {
        return ResponseEntity.ok(cartService.addItem(user.getUsername(), req));
    }

    @PatchMapping("/items")
    public ResponseEntity<Cart> updateItem(@AuthenticationPrincipal UserDetails user,
                                           @Valid @RequestBody CartDto.UpdateItemRequest req) {
        return ResponseEntity.ok(cartService.updateItem(user.getUsername(), req));
    }

    @DeleteMapping
    public ResponseEntity<Void> clearCart(@AuthenticationPrincipal UserDetails user) {
        cartService.clearCart(user.getUsername());
        return ResponseEntity.noContent().build();
    }
}

// ════════════════════════════════════════════
//  ORDER CONTROLLER
// ════════════════════════════════════════════
@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
class OrderController {

    private final OrderService orderService;

    @PostMapping
    public ResponseEntity<OrderDto.OrderResponse> createOrder(
            @AuthenticationPrincipal UserDetails user,
            @Valid @RequestBody OrderDto.CreateOrderRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(orderService.createOrder(user.getUsername(), req));
    }

    @GetMapping
    public ResponseEntity<Page<OrderDto.OrderResponse>> getMyOrders(
            @AuthenticationPrincipal UserDetails user,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(orderService.getUserOrders(user.getUsername(), page, size));
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderDto.OrderResponse> getOrder(
            @AuthenticationPrincipal UserDetails user,
            @PathVariable String orderId) {
        return ResponseEntity.ok(orderService.getOrder(orderId, user.getUsername()));
    }
}

// ════════════════════════════════════════════
//  ADMIN CONTROLLER
// ════════════════════════════════════════════
@RestController
@RequestMapping("/api/v1/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
class AdminController {

    private final ProductService productService;
    private final OrderService orderService;

    // Products
    @PostMapping("/products")
    public ResponseEntity<ProductDto.ProductResponse> createProduct(
            @Valid @RequestBody ProductDto.CreateProductRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(productService.createProduct(req));
    }

    @PatchMapping("/products/{id}")
    public ResponseEntity<ProductDto.ProductResponse> updateProduct(
            @PathVariable String id,
            @RequestBody ProductDto.UpdateProductRequest req) {
        return ResponseEntity.ok(productService.updateProduct(id, req));
    }

    @DeleteMapping("/products/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable String id) {
        productService.deleteProduct(id);
        return ResponseEntity.noContent().build();
    }

    // Orders
    @GetMapping("/orders")
    public ResponseEntity<Page<OrderDto.OrderResponse>> getAllOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(orderService.getAllOrders(page, size));
    }

    @PatchMapping("/orders/{id}/status")
    public ResponseEntity<OrderDto.OrderResponse> updateOrderStatus(
            @PathVariable String id,
            @Valid @RequestBody OrderDto.UpdateStatusRequest req) {
        return ResponseEntity.ok(orderService.updateStatus(id, req));
    }

    // Dashboard stats
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        return ResponseEntity.ok(Map.of(
                "status", "operational",
                "brand", "ZESUS Maison de Couture"
        ));
    }
}
