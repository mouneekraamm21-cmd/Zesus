package com.zesus.service;

import com.zesus.dto.AuthDto;
import com.zesus.dto.UserDto;
import com.zesus.exception.ApiException;
import com.zesus.model.User;
import com.zesus.repository.UserRepository;
import com.zesus.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Set;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;

    @Value("${zesus.jwt.expiration-ms}")
    private long expirationMs;

    public AuthDto.TokenResponse register(AuthDto.RegisterRequest req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new ApiException("Email already registered", HttpStatus.CONFLICT);
        }

        User user = User.builder()
                .email(req.getEmail().toLowerCase().trim())
                .password(passwordEncoder.encode(req.getPassword()))
                .firstName(req.getFirstName())
                .lastName(req.getLastName())
                .phone(req.getPhone())
                .roles(Set.of(User.Role.ROLE_CUSTOMER))
                .build();

        String refreshToken = jwtUtil.generateRefreshToken();
        user.setRefreshToken(refreshToken);
        userRepository.save(user);

        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        String accessToken = jwtUtil.generateAccessToken(userDetails);

        log.info("New customer registered: {}", user.getEmail());
        return new AuthDto.TokenResponse(accessToken, refreshToken, expirationMs, toUserResponse(user));
    }

    public AuthDto.TokenResponse login(AuthDto.LoginRequest req) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(req.getEmail().toLowerCase(), req.getPassword())
            );
        } catch (BadCredentialsException e) {
            throw new ApiException("Invalid email or password", HttpStatus.UNAUTHORIZED);
        }

        User user = userRepository.findByEmail(req.getEmail().toLowerCase())
                .orElseThrow(() -> new ApiException("User not found", HttpStatus.NOT_FOUND));

        String refreshToken = jwtUtil.generateRefreshToken();
        user.setRefreshToken(refreshToken);
        userRepository.save(user);

        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        String accessToken = jwtUtil.generateAccessToken(userDetails);

        return new AuthDto.TokenResponse(accessToken, refreshToken, expirationMs, toUserResponse(user));
    }

    public AuthDto.TokenResponse refresh(AuthDto.RefreshRequest req) {
        User user = userRepository.findByRefreshToken(req.getRefreshToken())
                .orElseThrow(() -> new ApiException("Invalid refresh token", HttpStatus.UNAUTHORIZED));

        String newRefreshToken = jwtUtil.generateRefreshToken();
        user.setRefreshToken(newRefreshToken);
        userRepository.save(user);

        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        String accessToken = jwtUtil.generateAccessToken(userDetails);

        return new AuthDto.TokenResponse(accessToken, newRefreshToken, expirationMs, toUserResponse(user));
    }

    public void logout(String email) {
        userRepository.findByEmail(email).ifPresent(user -> {
            user.setRefreshToken(null);
            userRepository.save(user);
        });
    }

    private UserDto.UserResponse toUserResponse(User user) {
        UserDto.UserResponse res = new UserDto.UserResponse();
        res.setId(user.getId());
        res.setEmail(user.getEmail());
        res.setFirstName(user.getFirstName());
        res.setLastName(user.getLastName());
        res.setPhone(user.getPhone());
        res.setRoles(user.getRoles());
        res.setDefaultAddress(user.getDefaultAddress());
        res.setCreatedAt(user.getCreatedAt());
        return res;
    }
}
