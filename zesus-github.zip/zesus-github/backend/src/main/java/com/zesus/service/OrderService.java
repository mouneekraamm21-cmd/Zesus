package com.zesus.service;

import com.zesus.dto.OrderDto;
import com.zesus.exception.ApiException;
import com.zesus.model.Cart;
import com.zesus.model.Order;
import com.zesus.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final CartService cartService;

    // Thread-safe order number counter (use a DB sequence in production)
    private final AtomicLong orderCounter = new AtomicLong(1);

    public OrderDto.OrderResponse createOrder(String userId, OrderDto.CreateOrderRequest req) {
        Cart cart = cartService.getCart(userId);

        if (cart.getItems().isEmpty()) {
            throw new ApiException("Cart is empty", HttpStatus.BAD_REQUEST);
        }

        BigDecimal subtotal = cartService.calculateSubtotal(cart);
        BigDecimal shipping = subtotal.compareTo(new BigDecimal("500")) >= 0 ? BigDecimal.ZERO : new BigDecimal("25");
        BigDecimal tax = subtotal.multiply(new BigDecimal("0.20")); // 20% VAT
        BigDecimal discount = cart.getDiscountAmount() != null ? cart.getDiscountAmount() : BigDecimal.ZERO;
        BigDecimal total = subtotal.add(shipping).add(tax).subtract(discount);

        List<Order.OrderItem> items = cart.getItems().stream().map(ci ->
                Order.OrderItem.builder()
                        .productId(ci.getProductId())
                        .productName(ci.getProductName())
                        .sku(ci.getSku())
                        .size(ci.getSize())
                        .color(ci.getColor())
                        .imageUrl(ci.getImageUrl())
                        .quantity(ci.getQuantity())
                        .unitPrice(ci.getUnitPrice())
                        .totalPrice(ci.getUnitPrice().multiply(BigDecimal.valueOf(ci.getQuantity())))
                        .build()
        ).toList();

        Order order = Order.builder()
                .orderNumber(generateOrderNumber())
                .userId(userId)
                .items(items)
                .shippingAddress(req.getShippingAddress())
                .billingAddress(req.getBillingAddress() != null ? req.getBillingAddress() : req.getShippingAddress())
                .subtotal(subtotal)
                .shippingCost(shipping)
                .tax(tax)
                .discount(discount)
                .total(total)
                .currency("EUR")
                .couponCode(req.getCouponCode())
                .notes(req.getNotes())
                .estimatedDelivery(Instant.now().plus(7, ChronoUnit.DAYS))
                .build();

        Order saved = orderRepository.save(order);
        cartService.clearCart(userId);  // clear cart after order

        log.info("Order {} created for user {}", saved.getOrderNumber(), userId);
        return toResponse(saved);
    }

    public Page<OrderDto.OrderResponse> getUserOrders(String userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return orderRepository.findByUserId(userId, pageable).map(this::toResponse);
    }

    public OrderDto.OrderResponse getOrder(String orderId, String userId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ApiException("Order not found", HttpStatus.NOT_FOUND));

        // Ensure order belongs to this user (unless admin — handled at controller level)
        if (!order.getUserId().equals(userId)) {
            throw new ApiException("Access denied", HttpStatus.FORBIDDEN);
        }
        return toResponse(order);
    }

    // Admin
    public Page<OrderDto.OrderResponse> getAllOrders(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return orderRepository.findAll(pageable).map(this::toResponse);
    }

    public OrderDto.OrderResponse updateStatus(String orderId, OrderDto.UpdateStatusRequest req) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ApiException("Order not found", HttpStatus.NOT_FOUND));
        order.setStatus(req.getStatus());
        return toResponse(orderRepository.save(order));
    }

    // ── Helpers ───────────────────────────────────

    private String generateOrderNumber() {
        return String.format("ZSS-%08d", orderCounter.getAndIncrement());
    }

    private OrderDto.OrderResponse toResponse(Order o) {
        OrderDto.OrderResponse r = new OrderDto.OrderResponse();
        r.setId(o.getId());
        r.setOrderNumber(o.getOrderNumber());
        r.setItems(o.getItems());
        r.setShippingAddress(o.getShippingAddress());
        r.setSubtotal(o.getSubtotal());
        r.setShippingCost(o.getShippingCost());
        r.setTax(o.getTax());
        r.setDiscount(o.getDiscount());
        r.setTotal(o.getTotal());
        r.setCurrency(o.getCurrency());
        r.setStatus(o.getStatus());
        r.setPayment(o.getPayment());
        r.setEstimatedDelivery(o.getEstimatedDelivery());
        r.setCreatedAt(o.getCreatedAt());
        return r;
    }
}
