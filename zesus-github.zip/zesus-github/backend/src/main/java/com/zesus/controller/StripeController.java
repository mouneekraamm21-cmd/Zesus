package com.zesus.controller;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import com.zesus.model.Cart;
import com.zesus.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
public class StripeController {

    @Value("${stripe.secret-key:sk_test_placeholder}")
    private String stripeSecretKey;

    private final CartService cartService;

    /**
     * Creates a Stripe Checkout Session from the user's current cart.
     * Returns a URL to redirect the user to Stripe's hosted checkout page.
     *
     * Frontend usage:
     *   const { url } = await api('/payments/create-checkout-session', { method: 'POST' });
     *   window.location.href = url;
     */
    @PostMapping("/create-checkout-session")
    public ResponseEntity<Map<String, String>> createCheckoutSession(
            @AuthenticationPrincipal UserDetails user) throws StripeException {

        Stripe.apiKey = stripeSecretKey;

        Cart cart = cartService.getCart(user.getUsername());

        if (cart.getItems().isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Cart is empty"));
        }

        List<SessionCreateParams.LineItem> lineItems = cart.getItems().stream().map(item ->
                SessionCreateParams.LineItem.builder()
                        .setQuantity((long) item.getQuantity())
                        .setPriceData(
                                SessionCreateParams.LineItem.PriceData.builder()
                                        .setCurrency("eur")
                                        .setUnitAmount(
                                                item.getUnitPrice()
                                                        .multiply(new BigDecimal("100"))
                                                        .longValue()
                                        )
                                        .setProductData(
                                                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                        .setName(item.getProductName())
                                                        .addImage("https://zesus.com/placeholder.jpg")
                                                        .build()
                                        )
                                        .build()
                        )
                        .build()
        ).toList();

        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:3000/index.html?order=success")
                .setCancelUrl("http://localhost:3000/index.html?order=cancelled")
                .addAllLineItem(lineItems)
                .setCustomerEmail(user.getUsername())
                .build();

        Session session = Session.create(params);

        return ResponseEntity.ok(Map.of(
                "sessionId", session.getId(),
                "url", session.getUrl()
        ));
    }
}
