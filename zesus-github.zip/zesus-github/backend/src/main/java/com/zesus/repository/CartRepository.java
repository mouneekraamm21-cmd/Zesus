package com.zesus.repository;

import com.zesus.model.Cart;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface CartRepository extends MongoRepository<Cart, String> {
    Optional<Cart> findByUserId(String userId);
    Optional<Cart> findBySessionId(String sessionId);
    void deleteByUserId(String userId);
}
