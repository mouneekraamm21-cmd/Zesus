package com.zesus.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "carts")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Cart {

    @Id
    private String id;

    @Indexed
    private String userId;       // null for guest

    @Indexed
    private String sessionId;    // for guest carts

    @Builder.Default
    private List<CartItem> items = new ArrayList<>();

    private String couponCode;
    private BigDecimal discountAmount;

    @LastModifiedDate
    private Instant updatedAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CartItem {
        private String productId;
        private String productName;
        private String sku;
        private String size;
        private String color;
        private String imageUrl;
        private Integer quantity;
        private BigDecimal unitPrice;
    }
}
