package com.zesus.dto;

import com.zesus.model.Address;
import com.zesus.model.Order;
import com.zesus.model.Product;
import com.zesus.model.User;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Set;

// ── User DTOs ─────────────────────────────────

class UserDto {

    @Data
    public static class UserResponse {
        private String id;
        private String email;
        private String firstName;
        private String lastName;
        private String phone;
        private Set<User.Role> roles;
        private Address defaultAddress;
        private Instant createdAt;
    }

    @Data
    public static class UpdateProfileRequest {
        private String firstName;
        private String lastName;
        private String phone;
        private Address defaultAddress;
    }

    @Data
    public static class ChangePasswordRequest {
        @NotBlank
        private String currentPassword;
        @NotBlank @Size(min = 8)
        private String newPassword;
    }
}

// ── Product DTOs ──────────────────────────────

class ProductDto {

    @Data
    public static class ProductResponse {
        private String id;
        private String name;
        private String slug;
        private String description;
        private String shortDescription;
        private BigDecimal price;
        private BigDecimal compareAtPrice;
        private String currency;
        private String category;
        private String subcategory;
        private String collection;
        private String material;
        private String origin;
        private List<String> images;
        private List<Product.ProductVariant> variants;
        private List<String> tags;
        private boolean featured;
        private Double averageRating;
        private Integer reviewCount;
        private Instant createdAt;
    }

    @Data
    public static class CreateProductRequest {
        @NotBlank private String name;
        @NotBlank private String description;
        private String shortDescription;
        @NotNull @Positive private BigDecimal price;
        private BigDecimal compareAtPrice;
        @NotBlank private String category;
        private String subcategory;
        private String collection;
        private String material;
        private String origin;
        private List<String> images;
        private List<Product.ProductVariant> variants;
        private List<String> tags;
        private boolean featured;
    }

    @Data
    public static class UpdateProductRequest {
        private String name;
        private String description;
        private String shortDescription;
        private BigDecimal price;
        private BigDecimal compareAtPrice;
        private String category;
        private String subcategory;
        private String collection;
        private String material;
        private String origin;
        private List<String> images;
        private List<Product.ProductVariant> variants;
        private List<String> tags;
        private Boolean active;
        private Boolean featured;
    }
}

// ── Cart DTOs ─────────────────────────────────

class CartDto {

    @Data
    public static class AddItemRequest {
        @NotBlank private String productId;
        @NotBlank private String sku;
        private String size;
        private String color;
        @NotNull @Min(1) private Integer quantity;
    }

    @Data
    public static class UpdateItemRequest {
        @NotBlank private String sku;
        @NotNull @Min(0) private Integer quantity;  // 0 = remove
    }
}

// ── Order DTOs ────────────────────────────────

class OrderDto {

    @Data
    public static class CreateOrderRequest {
        @NotNull private Address shippingAddress;
        private Address billingAddress;   // defaults to shippingAddress
        private String couponCode;
        private String notes;
    }

    @Data
    public static class OrderResponse {
        private String id;
        private String orderNumber;
        private List<Order.OrderItem> items;
        private Address shippingAddress;
        private BigDecimal subtotal;
        private BigDecimal shippingCost;
        private BigDecimal tax;
        private BigDecimal discount;
        private BigDecimal total;
        private String currency;
        private Order.OrderStatus status;
        private Order.PaymentInfo payment;
        private Instant estimatedDelivery;
        private Instant createdAt;
    }

    @Data
    public static class UpdateStatusRequest {
        @NotNull private Order.OrderStatus status;
        private String notes;
    }
}
