package com.zesus.repository;

import com.zesus.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface ProductRepository extends MongoRepository<Product, String> {

    Optional<Product> findBySlug(String slug);

    Page<Product> findByActiveTrue(Pageable pageable);

    Page<Product> findByCategoryAndActiveTrue(String category, Pageable pageable);

    Page<Product> findByCollectionAndActiveTrue(String collection, Pageable pageable);

    List<Product> findByFeaturedTrueAndActiveTrue();

    @Query("{ 'active': true, 'price': { $gte: ?0, $lte: ?1 } }")
    Page<Product> findByPriceRange(BigDecimal min, BigDecimal max, Pageable pageable);

    @Query("{ 'active': true, $text: { $search: ?0 } }")
    Page<Product> searchByText(String query, Pageable pageable);

    @Query("{ 'active': true, 'category': ?0, 'price': { $gte: ?1, $lte: ?2 } }")
    Page<Product> findByCategoryAndPriceRange(String category, BigDecimal min, BigDecimal max, Pageable pageable);

    List<Product> findTop8ByActiveTrueOrderByCreatedAtDesc();
}
