package com.zesus.service;

import com.zesus.dto.CartDto;
import com.zesus.exception.ApiException;
import com.zesus.model.Cart;
import com.zesus.model.Product;
import com.zesus.repository.CartRepository;
import com.zesus.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final ProductRepository productRepository;

    public Cart getCart(String userId) {
        return cartRepository.findByUserId(userId)
                .orElseGet(() -> cartRepository.save(Cart.builder().userId(userId).build()));
    }

    public Cart addItem(String userId, CartDto.AddItemRequest req) {
        Cart cart = getCart(userId);

        // Validate product & variant
        Product product = productRepository.findById(req.getProductId())
                .orElseThrow(() -> new ApiException("Product not found", HttpStatus.NOT_FOUND));

        Product.ProductVariant variant = product.getVariants().stream()
                .filter(v -> v.getSku().equals(req.getSku()))
                .findFirst()
                .orElseThrow(() -> new ApiException("Variant/SKU not found", HttpStatus.BAD_REQUEST));

        if (variant.getStock() < req.getQuantity()) {
            throw new ApiException("Insufficient stock", HttpStatus.BAD_REQUEST);
        }

        BigDecimal unitPrice = product.getPrice().add(
                variant.getPriceAdjustment() != null ? variant.getPriceAdjustment() : BigDecimal.ZERO
        );

        // Check if item already in cart
        Optional<Cart.CartItem> existing = cart.getItems().stream()
                .filter(i -> i.getSku().equals(req.getSku()))
                .findFirst();

        if (existing.isPresent()) {
            existing.get().setQuantity(existing.get().getQuantity() + req.getQuantity());
        } else {
            Cart.CartItem item = Cart.CartItem.builder()
                    .productId(req.getProductId())
                    .productName(product.getName())
                    .sku(req.getSku())
                    .size(req.getSize())
                    .color(req.getColor())
                    .imageUrl(!product.getImages().isEmpty() ? product.getImages().get(0) : null)
                    .quantity(req.getQuantity())
                    .unitPrice(unitPrice)
                    .build();
            cart.getItems().add(item);
        }

        return cartRepository.save(cart);
    }

    public Cart updateItem(String userId, CartDto.UpdateItemRequest req) {
        Cart cart = getCart(userId);

        if (req.getQuantity() == 0) {
            cart.getItems().removeIf(i -> i.getSku().equals(req.getSku()));
        } else {
            cart.getItems().stream()
                    .filter(i -> i.getSku().equals(req.getSku()))
                    .findFirst()
                    .ifPresent(i -> i.setQuantity(req.getQuantity()));
        }

        return cartRepository.save(cart);
    }

    public Cart clearCart(String userId) {
        Cart cart = getCart(userId);
        cart.setItems(new ArrayList<>());
        cart.setCouponCode(null);
        cart.setDiscountAmount(null);
        return cartRepository.save(cart);
    }

    public BigDecimal calculateSubtotal(Cart cart) {
        return cart.getItems().stream()
                .map(i -> i.getUnitPrice().multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
