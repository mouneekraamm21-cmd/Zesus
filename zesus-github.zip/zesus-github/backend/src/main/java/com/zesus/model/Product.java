package com.zesus.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "products")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    @Id
    private String id;

    @TextIndexed(weight = 3)
    private String name;

    @Indexed(unique = true)
    private String slug;

    @TextIndexed
    private String description;

    private String shortDescription;

    private BigDecimal price;
    private BigDecimal compareAtPrice;  // Original price for sale items

    private String currency;

    @Indexed
    private String category;           // e.g. "womens", "mens", "accessories"

    private String subcategory;        // e.g. "coats", "dresses", "shirts"

    private String collection;         // e.g. "SS2026 — Olympus"

    @TextIndexed
    private String material;           // e.g. "Cashmere & Silk"

    private String origin;             // e.g. "Handcrafted in Florence"

    @Builder.Default
    private List<String> images = new ArrayList<>();

    @Builder.Default
    private List<ProductVariant> variants = new ArrayList<>();

    @Builder.Default
    private List<String> tags = new ArrayList<>();

    @Builder.Default
    private boolean active = true;

    @Builder.Default
    private boolean featured = false;

    private Integer stockQuantity;

    private Double averageRating;

    @Builder.Default
    private Integer reviewCount = 0;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProductVariant {
        private String sku;
        private String size;   // XS, S, M, L, XL, XXL or numeric
        private String color;
        private Integer stock;
        private BigDecimal priceAdjustment;  // +/- from base price
    }
}
